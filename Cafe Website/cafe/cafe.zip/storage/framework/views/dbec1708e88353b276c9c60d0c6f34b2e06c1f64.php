<h1><?php echo e($product->nama); ?></h1>
<a href="/products">< Back to Product List</a>
<br>
Kode Produk: <?php echo e($product->kode_produk); ?><br>
Nama Produk: <?php echo e($product->nama_produk); ?><br>
Kategori: <?php echo e($product->kategori); ?><br>
Deskripsi: <?php echo e($product->deskripsi); ?><br>
Stok: <?php echo e($product->stok); ?><br>
Tanggal Beli: <?php echo e($product->tgl_beli); ?><br>
Tanggal Kadaluwarsa: <?php echo e($product->tgl_kadaluwarsa); ?><br>
Supplier: <?php echo e($product->supplier); ?><br>
Photo:	<br><img src="<?php echo e(asset('storage/'.$product->foto)); ?>" width="300"><?php /**PATH C:\Users\ASUS\Dropbox\UAS-WebProg\cafe\resources\views/products/show.blade.php ENDPATH**/ ?>