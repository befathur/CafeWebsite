<h1>Edit Student</h1>
<a href="/products">< Back to Product List</a>
<form action="\products\<?php echo e($product->id); ?>" method="POST">
	<?php echo method_field('PUT'); ?>
	<?php echo csrf_field(); ?>
	Nama Produk: <input type="text" name="nama_produk" value="<?php echo e($product->nama_produk); ?>"><br>
	Kategori: <input type="text" name="kategori" value="<?php echo e($product->kategori); ?>"><br>
	Deskripsi: <textarea name="deskripsi"><?php echo e($product->deskripsi); ?></textarea><br>
	Stok: <input type="number" name="stok" value="<?php echo e($product->stok); ?>"><br>
	Tanggal Beli: <input type="date" name="tgl_beli" value="<?php echo e($product->tgl_beli); ?>"><br>
	Tanggal Kadaluwarsa: <input type="date" name="tgl_kadaluwarsa" value="<?php echo e($product->tgl_kadaluwarsa); ?>"><br>
	Supplier: <input type="text" name="supplier" value="<?php echo e($product->supplier); ?>"><br>
	<button type="submit">Submit</button>
</form><?php /**PATH C:\Users\ASUS\Dropbox\UAS-WebProg\cafe\resources\views/products/edit.blade.php ENDPATH**/ ?>