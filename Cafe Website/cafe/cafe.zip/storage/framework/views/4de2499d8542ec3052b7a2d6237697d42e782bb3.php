<h1>Add New Product</h1>

<?php if($errors): ?>
	<ul>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
<?php endif; ?>

<a href="/products">< Back to Product List</a>
<form action="\products" method="POST" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	Nama Produk: <input type="text" name="nama_produk"><br>
	Kategori: <input type="text" name="kategori"><br>
	Deskripsi: <textarea name="deskripsi"></textarea><br>
	Stok: <input type="number" name="stok"><br>
	Tanggal Beli: <input type="date" name="tgl_beli"><br>
	Tanggal Kadaluwarsa: <input type="date" name="tgl_kadaluwarsa"><br>
	Supplier: <input type="text" name="supplier"><br>
	Foto: <input type="file" name="foto"><br><br>
	<button type="submit">Submit</button>
</form><?php /**PATH C:\Users\ASUS\Dropbox\UAS-WebProg\cafe\resources\views/products/create.blade.php ENDPATH**/ ?>