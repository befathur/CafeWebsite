<h1>Daftar Mahasiswa</h1>
<a href="/products/create">Create new Products</a>
<table border="1">
	<tr>
		<th>Nama Produk</th>
		<th>Kategori</th>
		<th>Deskripsi</th>
		<th>Stok</th>
		<th>Tanggal Beli</th>
		<th>Tanggal Kadaluwarsa</th>
		<th>Supplier</th>
		<th>Foto</th>
	</tr>
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($product->nama_produk); ?></td>
		<td><?php echo e($product->kategori); ?></td>
		<td><?php echo e($product->deskripsi); ?></td>
		<td><?php echo e($product->stok); ?></td>
		<td><?php echo e($product->tgl_beli); ?></td>
		<td><?php echo e($product->tgl_kadaluwarsa); ?></td>
		<td><?php echo e($product->supplier); ?></td>
		<td><img src="<?php echo e(asset('storage/'.$product->foto)); ?>" width="300"></td>
		<td>
			<a href="/products/<?php echo e($product->id); ?>">Show</a> |
			<a href="/products/<?php echo e($product->id); ?>/edit">Edit</a> |
			<form action="/products/<?php echo e($product->id); ?>" method="POST">
				<?php echo method_field('DELETE'); ?>
				<?php echo csrf_field(); ?>
				<button type="submit">Delete</button>
			</form>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\ASUS\Dropbox\UAS-WebProg\cafe\resources\views/products/index.blade.php ENDPATH**/ ?>